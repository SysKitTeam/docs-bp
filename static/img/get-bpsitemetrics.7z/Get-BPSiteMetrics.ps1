# ===================================================================================
# Get-BPSiteMetrics
# Author: Aleksandar Draskovic
# Date: 2015-05-15
# ===================================================================================

<#
	.SYNOPSIS
		Extracts the web application and site collection metrics.


	.DESCRIPTION
		This script extracts the web application and site collection metrics. It also checks if the site collection is within 100GB boundaries and contains less than 250.000 site collections. It extracts the following information:
		- Web application name, URL, site collections count and a list of site collections
		- Site collection URL, site count, database name and storage used
	

	.PARAMETER OutputFile
		Defines a path to the output file. Default: <script folder>\SiteMetrics.xml		
		

	.EXAMPLE
		Get-BPSiteMetrics
        
        Extracts the web application and site collection metrics
    
#>
param(
[string]$OutputFile = "$(split-path -parent $MyInvocation.MyCommand.Definition)\SiteMetrics.xml"
)

Write-Host "Extracting structure information to $OutputFile..."
"<Metrics>" | Out-File -FilePath $OutputFile -Append:$false

$spWebApps = Get-SPWebApplication
$spWAcount = 1
foreach ($spWebApp in $spWebApps)
{
	$percentComplete = [int](($spWAcount*100)/$spWebApps.Count)
	Write-Progress -Activity "Reading SharePoint farm structure..." -Status "Enumerating Web Applications, $percentComplete% completed..." -Id 0 -PercentComplete $percentComplete -CurrentOperation "Web Application: $($spWebApp.DisplayName) [Url: $($spWebApp.Url)]"
	"`t<WebApplication DisplayName='$($spWebApp.DisplayName)' Url='$($spWebApp.Url)' SiteCount='$($spWebApp.Sites.Count)'>" | Out-File -FilePath $OutputFile -Append:$true
	# export $spWebApp.DisplayName
	# export $spWebApp.Url
	# export $spWebApp.Sites.Count, check if bigger than ?
	$spSiteCount = 1
	
	foreach ($spSite in $spWebApp.Sites)
	{
		$sitePercentComplete = [int](($spSiteCount*100)/$spWebApp.Sites.Count)
		Write-Progress -Activity "Enumerating site collections, $sitePercentComplete% completed..." -Id 1 -PercentComplete $sitePercentComplete -CurrentOperation "Site collection: $($spSite.Url)" -ParentId 0
		# export $spSite.Url
		# export $spSite.Usage.Storage, check if bigger than 100GB
		# export $spSite.AllWebs.Count, check if bigger than 250.000	
		"`t`t<SiteCollection Url='$($spSite.Url)' Database='$($spSite.ContentDatabase.Name)' Storage='$($spSite.Usage.Storage)' WebCount='$($spSite.AllWebs.Count)'/>" | Out-File -FilePath $OutputFile -Append:$true
		if ($spSite.Usage.Storage -gt 100GB)
		{
			Write-Host "Warning: site collection $($spSite.Url) is larger than 100GB. Site collection size: $([int]($spSite.Usage.Storage/1GB))GB" -ForegroundColor Yellow
		}
		
		if ($spSite.AllWebs.Count -gt 250000)
		{
			Write-Host "Warning: site collection $($spSite.Url) has more than 250.000 sites. Number of sites: $($spSite.AllWebs.Count)" -ForegroundColor Yellow
		}
		
		$spSiteCount++
	}
	"`t</WebApplication>" | Out-File -FilePath $OutputFile -Append:$true
	$spWAcount++
}
"</Metrics>" | Out-File -FilePath $OutputFile -Append:$true